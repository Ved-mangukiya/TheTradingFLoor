# SYSTEM ARCHITECTURE — THE TRADING FLOOR CHAMPIONSHIP 2026

## 1. High-Level Architecture Overview

The Trading Floor Championship is architected as an offline-first, client-server application built with Node.js, Express, native WebSockets (`ws`), and vanilla HTML5/CSS3/JavaScript.

```
                      +---------------------------------------+
                      |           Node.js Server              |
                      |   Express HTTP (Static + REST API)    |
                      |   WebSocket Server (Port 3000)        |
                      +-------------------+-------------------+
                                          |
                     +--------------------+--------------------+
                     |                                         |
     Persistent Storage (JSON)                       Live In-Memory State
     ├── data/scenario_live.json                     ├── Companies Universe
     ├── data/scenario_test.json                     ├── Teams & Portfolios
     ├── data/universe_active.json                   ├── Executed Trades Ledger
     └── logs/AUDIT_LOG_*.json                       └── Active News & Clocks
                     |                                         |
         +-----------+-----------------------------------------+-----------+
         |                                 |                               |
+--------v---------+             +---------v--------+            +---------v--------+
|   Host Control   |             |   Trader Desks   |            | Stage Projector  |
|  (Master Matrix) |             |  (Student Teams) |            |  (Full Screen)   |
+------------------+             +------------------+            +------------------+
```

---

## 2. Core Subsystems

### 2.1 Authoritative Market Price Engine
- **Tick Interval**: Runs on an atomic 1500ms `setInterval` loop in `server.js`.
- **Geometric Random Walk with Mean Reversion**:
  $$P_{t+1} = P_t \times \left(1 + \mu \cdot dt + \sigma \cdot \epsilon \cdot \sqrt{dt} - \kappa (P_t - P_{\text{baseline}})\right)$$
  - $\sigma$: Stock-specific volatility factor (default: `0.004` to `0.012`).
  - $\epsilon$: Normal Gaussian perturbation using Box-Muller transform.
  - $\kappa$: Mean reversion force anchoring extreme drifts back towards economic reality.
- **Active Transition Shock Engine**: When news breaks, target stocks undergo exponential price adjustments over 30–60 seconds, weighted by each company's $\beta$ (news sensitivity).
- **Circuit Breakers**: Evaluated on every tick. If $|P_t - P_{\text{day\_open}}| / P_{\text{day\_open}} \ge \text{Limit}$ (default: 20%), trading in that stock is immediately frozen, setting `isHalted = true` and broadcasting a circuit breaker alarm.

### 2.2 WebSocket Communication Protocol
All real-time interaction occurs over a persistent WebSocket connection:
- **Authentication**: Clients send `{ action: 'LOGIN', username, password }`. The server validates against registered credentials and returns a 32-character cryptographic session token (`session_token`).
- **Session Continuity**: If a browser tab disconnects or reloads, the client automatically transmits `{ action: 'RESUME_SESSION', session_token }`. The server reconnects the existing session and pushes the latest authoritative state without losing portfolio data.
- **Role-Based Sanitized State Broadcast**:
  - `TRADER`: Receives only tradeable enabled stocks, team's own portfolio/cash, team's own executed trades, public leaderboard, and active news flash. Never receives other teams' private holdings.
  - `PROJECTOR`: Receives public enabled stocks, top 5 leaderboard rankings, and active news flashes.
  - `HOST`: Receives full administrative state including `allCompaniesUniverse` (both enabled and disabled shares), all teams' raw balances, all executed trades, and audit counters.

### 2.3 Offline Institutional Audio Engine
To operate without internet and without external audio assets:
- Implemented in `public/app.js` using the standard browser **Web Audio API** (`AudioContext`).
- Generates 4 distinct synthetic cues entirely in code:
  1. `bell_open` / `bell_close`: Multi-harmonic chime (C5-E5-G5-C6) with exponential decay.
  2. `news_siren`: Two-tone frequency modulated sawtooth siren (440Hz -> 880Hz).
  3. `circuit_alarm`: Rapid 4-burst square wave alarm (620Hz).
  4. `championship_fanfare`: Grand victory fanfare (G4-C5-E5-G5-C6) for the winner podium.

### 2.4 Data Persistence & Crash Recovery
- **Active Share Universe**: Stored in `data/universe_active.json`. Created or modified whenever the host adds, edits, toggles, duplicates, or randomizes shares.
- **Audit Ledger**: Stored in `logs/AUDIT_LOG_<timestamp>.json`. Written periodically and on every trade/pause/halt event using non-blocking asynchronous disk writes.
- **Full State Backup & Restore API**:
  - `GET /api/backup`: Serializes game state, teams, companies, and executed trades into a complete JSON snapshot.
  - `POST /api/restore`: Ingests a previously exported snapshot and re-establishes server state cleanly.
